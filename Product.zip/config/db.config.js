const MYSQL_DB_CONFIG = {
    HOST: "localhost",      // In production give ip URL
    USER: "root",           // In production  ignore root
    PORT: 3306,
    PASSWORD: "",
    DB: "ecom_db",
  };
  module.exports = {
    MYSQL_DB_CONFIG,
  };